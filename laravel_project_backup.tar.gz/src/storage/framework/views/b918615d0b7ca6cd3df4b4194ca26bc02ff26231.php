<!-- resources/views/payment_success.blade.php -->


<?php $__env->startSection('css'); ?>
<link rel="stylesheet" href="<?php echo e(asset('css/payment_success.css')); ?>">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<main class="success__content">
    <div class="success__message-box">
        <p class="success__message">決済が成功しました！</p>
        <a href="<?php echo e(route('home')); ?>" class="home-button">ホームに戻る</a>
    </div>
</main>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.rese_layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/resources/views/payment_success.blade.php ENDPATH**/ ?>