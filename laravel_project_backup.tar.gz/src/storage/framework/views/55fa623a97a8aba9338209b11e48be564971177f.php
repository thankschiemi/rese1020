<?php $__env->startSection('css'); ?>
<link rel="stylesheet" href="<?php echo e(asset('css/edit_store.css')); ?>">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<main class="edit-store">
    <a href="/owner/dashboard" class="btn btn-primary">ダッシュボードに戻る</a>
    <h1 class="edit-store__title"><?php echo e($store ? '店舗情報編集' : '店舗新規作成'); ?></h1>
    <form class="edit-store__form" method="POST" action="<?php echo e($store ? route('owner.update_store', $store->id) : route('owner.store_store')); ?>" novalidate>
        <?php echo csrf_field(); ?>
        <?php if($store): ?>
        <?php echo method_field('PUT'); ?>
        <?php endif; ?>

        <?php if(session('success')): ?>
        <p class="alert alert-success"><?php echo e(session('success')); ?></p>
        <?php endif; ?>

        <div class="edit-store__form-group">
            <label class="edit-store__label" for="name">店舗名</label>
            <input class="edit-store__input" type="text" name="name" value="<?php echo e(old('name', $store->name ?? '')); ?>">
            <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <div class="error-message"><?php echo e($message); ?></div>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>

        <div class="edit-store__form-group">
            <label class="edit-store__label" for="region_id">地域</label>
            <select class="edit-store__input" name="region_id" required>
                <?php $__currentLoopData = $regions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $region): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($region->id); ?>" <?php echo e((old('region_id', $store->region_id ?? '') == $region->id) ? 'selected' : ''); ?>><?php echo e($region->name); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
            <?php $__errorArgs = ['region_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <div class="error-message"><?php echo e($message); ?></div>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>

        <div class="edit-store__form-group">
            <label class="edit-store__label" for="genre_id">ジャンル</label>
            <select class="edit-store__input" name="genre_id" required>
                <?php $__currentLoopData = $genres; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $genre): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($genre->id); ?>" <?php echo e((old('genre_id', $store->genre_id ?? '') == $genre->id) ? 'selected' : ''); ?>><?php echo e($genre->name); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
            <?php $__errorArgs = ['genre_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <div class="error-message"><?php echo e($message); ?></div>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>

        <div class="edit-store__form-group">
            <label class="edit-store__label" for="description">店舗概要</label>
            <textarea class="edit-store__input" name="description"><?php echo e(old('description', $store->description ?? '')); ?></textarea>
            <?php $__errorArgs = ['description'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <div class="error-message"><?php echo e($message); ?></div>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>

        <div class="edit-store__form-group">
            <label class="edit-store__label" for="image_url">画像URL</label>
            <input class="edit-store__input" type="text" name="image_url" value="<?php echo e(old('image_url', $store->image_url ?? '')); ?>">
            <?php $__errorArgs = ['image_url'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <div class="error-message"><?php echo e($message); ?></div>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>

        <button class="edit-store__button" type="submit"><?php echo e($store ? '更新' : '作成'); ?></button>
    </form>
</main>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.rese_layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/resources/views/owner/edit_store.blade.php ENDPATH**/ ?>