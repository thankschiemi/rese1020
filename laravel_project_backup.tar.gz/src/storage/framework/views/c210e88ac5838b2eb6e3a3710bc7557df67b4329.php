<?php $__env->startSection('css'); ?>
<link rel="stylesheet" href="<?php echo e(asset('css/reservation_edit.css')); ?>">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<main class="reservation-edit">
    <a href="<?php echo e(route('mypage')); ?>" class="reservation-edit__back-btn">マイページに戻る</a>
    <h1 class="reservation-edit__title">予約変更</h1>
    <form class="reservation-edit__form" action="<?php echo e(route('reserve.update', $reservation->id)); ?>" method="POST">
        <?php echo csrf_field(); ?>
        <?php echo method_field('PUT'); ?>

        <!-- 日付フィールド -->
        <div class="reservation-edit__form-group">
            <label class="reservation-edit__label" for="reservation_date">Date</label>
            <input class="reservation-edit__input <?php $__errorArgs = ['reservation_date'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" type="date" name="reservation_date" value="<?php echo e(old('reservation_date', $reservation->reservation_date)); ?>" required>
            <?php $__errorArgs = ['reservation_date'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <div class="reservation-edit__error-message"><?php echo e($message); ?></div>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>

        <!-- 時間フィールド -->
        <div class="reservation-edit__form-group">
            <label class="reservation-edit__label" for="reservation_time">Time</label>
            <input class="reservation-edit__input <?php $__errorArgs = ['reservation_time'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" type="time" name="reservation_time" value="<?php echo e(old('reservation_time', date('H:i', strtotime($reservation->reservation_time)))); ?>" required>
            <?php $__errorArgs = ['reservation_time'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <div class="reservation-edit__error-message"><?php echo e($message); ?></div>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>

        <!-- 人数フィールド -->
        <div class="reservation-edit__form-group">
            <label class="reservation-edit__label" for="number_of_people">Number</label>
            <input class="reservation-edit__input <?php $__errorArgs = ['number_of_people'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" type="number" name="number_of_people" value="<?php echo e(old('number_of_people', $reservation->number_of_people)); ?>" min="1" required>
            <?php $__errorArgs = ['number_of_people'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <div class="reservation-edit__error-message"><?php echo e($message); ?></div>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>

        <button class="reservation-edit__button" type="submit">変更する</button>
    </form>
</main>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.rese_layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/resources/views/reservations/edit.blade.php ENDPATH**/ ?>