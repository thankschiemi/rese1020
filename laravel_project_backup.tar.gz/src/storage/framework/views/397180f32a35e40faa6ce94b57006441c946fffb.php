<?php $__env->startSection('content'); ?>
<link rel="stylesheet" href="<?php echo e(asset('css/users.css')); ?>">

<div class="user-management__container">
    <h1 class="user-management__title">ユーザー管理</h1>
</div>

<!-- 新規作成カード -->
<div class="user-management__card user-management__card--form">
    <a href="<?php echo e(route('admin.dashboard')); ?>" class="user-management__back-btn">ダッシュボードに戻る</a>
    <h2 class="user-management__subtitle">店舗代表者の新規作成</h2>
    <?php if(session('success_create')): ?>
    <p class="user-management__success"><?php echo e(session('success_create')); ?></p>
    <?php endif; ?>

    <form method="POST" action="<?php echo e(route('admin.users.store')); ?>" class="user-management__form" novalidate>
        <?php echo csrf_field(); ?>
        <div class="user-management__form-group">
            <span class="user-management__icon">
                <i class="fas fa-user"></i>
            </span>
            <input type="text" id="name" name="name" class="user-management__input" placeholder="名前" required>
            <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <p class="user-management__error"><?php echo e($message); ?></p>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>
        <div class="user-management__form-group">
            <span class="user-management__icon">
                <i class="fas fa-envelope"></i>
            </span>
            <input type="email" id="email" name="email" class="user-management__input" placeholder="メールアドレス" required>
            <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <p class="user-management__error"><?php echo e($message); ?></p>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>
        <div class="user-management__form-group">
            <span class="user-management__icon">
                <i class="fas fa-lock"></i>
            </span>
            <input type="password" id="password" name="password" class="user-management__input" placeholder="パスワード" required>
            <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <p class="user-management__error"><?php echo e($message); ?></p>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>
        <div class="user-management__form-group">
            <span class="user-management__icon">
                <i class="fas fa-lock"></i>
            </span>
            <input type="password" id="password_confirmation" name="password_confirmation" class="user-management__input" placeholder="パスワード確認" required>
        </div>
        <button type="submit" class="user-management__button">作成</button>
    </form>
</div>

<!-- 登録済みユーザー権限変更カード -->
<div class="user-management__card user-management__card--table">

    <h2 class="user-management__subtitle">登録済みユーザーの権限変更</h2>
    <?php if(session('success_update')): ?>
    <p class="user-management__success"><?php echo e(session('success_update')); ?></p>
    <?php endif; ?>

    <p class="user-management__description">登録済みのユーザーの権限を変更できます。</p>

    <table class="user-management__table">
        <thead class="user-management__table-header">
            <tr>
                <th class="user-management__table-header-cell">ID</th>
                <th class="user-management__table-header-cell">名前</th>
                <th class="user-management__table-header-cell">メールアドレス</th>
                <th class="user-management__table-header-cell">現在の権限</th>
                <th class="user-management__table-header-cell">操作</th>
            </tr>
        </thead>
        <tbody class="user-management__table-body">
            <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr class="user-management__table-row">
                <td class="user-management__table-cell"><?php echo e($user->id); ?></td>
                <td class="user-management__table-cell"><?php echo e($user->name); ?></td>
                <td class="user-management__table-cell"><?php echo e($user->email); ?></td>
                <td class="user-management__table-cell"><?php echo e($user->role); ?></td>
                <td class="user-management__table-cell">
                    <form method="POST" action="<?php echo e(route('admin.users.updateRole', $user->id)); ?>" class="user-management__form">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('PUT'); ?>
                        <select name="role" class="user-management__select" required>
                            <option value="user" <?php echo e($user->role === 'user' ? 'selected' : ''); ?>>利用者</option>
                            <option value="owner" <?php echo e($user->role === 'owner' ? 'selected' : ''); ?>>店舗代表者</option>
                            <option value="admin" <?php echo e($user->role === 'admin' ? 'selected' : ''); ?>>管理者</option>
                        </select>
                        <button type="submit" class="user-management__button">変更</button>
                    </form>
                </td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.rese_layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/resources/views/admin/users.blade.php ENDPATH**/ ?>