<?php $__env->startSection('css'); ?>
<link rel="stylesheet" href="<?php echo e(asset('css/restaurant_detail.css')); ?>">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

<main class="shop-page__content">
    <!-- レストラン情報の表示 -->
    <section class="shop-info">
        <div class="shop-info__header">
            <a href="<?php echo e(url()->previous()); ?>" class="shop-info__back-button">◀</a>
            <h2 class="shop-info__name"><?php echo e($restaurant->name); ?></h2>
        </div>

        <div class="shop-info__image">
            <?php if(!empty($restaurant->image_url) && file_exists(public_path('storage/' . $restaurant->image_url))): ?>
            <!-- 画像が存在する場合 -->
            <img src="<?php echo e(asset('storage/' . $restaurant->image_url)); ?>" alt="<?php echo e($restaurant->name); ?>の画像" class="restaurant__image">
            <?php else: ?>
            <!-- デフォルト画像を表示 -->
            <img src="<?php echo e(asset('images/default-image.png')); ?>" alt="デフォルト画像" class="default-image">
            <?php endif; ?>
        </div>

        <p class="shop-info__tags">
            #<?php echo e($restaurant->region->name); ?> #<?php echo e($restaurant->genre->name); ?>

        </p>
        <p class="shop-info__description">
            <?php echo e($restaurant->description); ?>

        </p>
    </section>


    <!-- 予約フォーム -->
    <section class="reservation-form">
        <h2 class="reservation-form__title">予約</h2>

        <!-- フォーム -->
        <form action="<?php echo e(route('reserve.store')); ?>" method="POST" class="reservation-form__form" novalidate>
            <?php echo csrf_field(); ?>
            <input type="hidden" name="restaurant_id" value="<?php echo e($restaurant->id); ?>">
            <input type="hidden" name="member_id" value="1">

            <!-- 日付フィールド -->
            <div class="reservation-form__group">
                <label for="date" class="reservation-form__label"></label>
                <input type="date" id="date" name="date"
                    value="<?php echo e(old('date')); ?>"
                    class="reservation-form__input reservation-form__input--date <?php $__errorArgs = ['date'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" required>
                <?php $__errorArgs = ['date'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <div class="reservation-form__error-message"><?php echo e($message); ?></div>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>

            <!-- 時間フィールド -->
            <div class="reservation-form__group">
                <label for="time" class="reservation-form__label"></label>
                <select id="time" name="time"
                    class="reservation-form__select reservation-form__select--time" required>
                    <option value="" disabled <?php echo e(old('time') ? '' : 'selected'); ?>>時間を選択</option>
                    <option value="09:00" <?php echo e(old('time') == '09:00' ? 'selected' : ''); ?>>09:00</option>
                    <option value="10:00" <?php echo e(old('time') == '10:00' ? 'selected' : ''); ?>>10:00</option>
                    <option value="11:00" <?php echo e(old('time') == '11:00' ? 'selected' : ''); ?>>11:00</option>
                    <option value="12:00" <?php echo e(old('time') == '12:00' ? 'selected' : ''); ?>>12:00</option>
                    <option value="13:00" <?php echo e(old('time') == '13:00' ? 'selected' : ''); ?>>13:00</option>
                    <option value="14:00" <?php echo e(old('time') == '14:00' ? 'selected' : ''); ?>>14:00</option>
                    <option value="15:00" <?php echo e(old('time') == '15:00' ? 'selected' : ''); ?>>15:00</option>
                    <option value="16:00" <?php echo e(old('time') == '16:00' ? 'selected' : ''); ?>>16:00</option>
                    <option value="17:00" <?php echo e(old('time') == '17:00' ? 'selected' : ''); ?>>17:00</option>
                    <option value="18:00" <?php echo e(old('time') == '18:00' ? 'selected' : ''); ?>>18:00</option>
                    <option value="19:00" <?php echo e(old('time') == '19:00' ? 'selected' : ''); ?>>19:00</option>
                    <option value="20:00" <?php echo e(old('time') == '20:00' ? 'selected' : ''); ?>>20:00</option>
                    <option value="21:00" <?php echo e(old('time') == '21:00' ? 'selected' : ''); ?>>21:00</option>
                    <option value="22:00" <?php echo e(old('time') == '22:00' ? 'selected' : ''); ?>>22:00</option>
                </select>
                <?php $__errorArgs = ['time'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <div class="reservation-form__error-message"><?php echo e($message); ?></div>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>

            <!-- 人数フィールド -->
            <div class="reservation-form__group">
                <label for="number" class="reservation-form__label"></label>
                <select id="number" name="number"
                    class="reservation-form__select reservation-form__select--people" required>
                    <option value="" disabled <?php echo e(old('number') ? '' : 'selected'); ?>>人数を選択</option>
                    <option value="1" <?php echo e(old('number') == 1 ? 'selected' : ''); ?>>1人</option>
                    <option value="2" <?php echo e(old('number') == 2 ? 'selected' : ''); ?>>2人</option>
                    <option value="3" <?php echo e(old('number') == 3 ? 'selected' : ''); ?>>3人</option>
                    <option value="4" <?php echo e(old('number') == 4 ? 'selected' : ''); ?>>4人</option>
                    <option value="5" <?php echo e(old('number') == 5 ? 'selected' : ''); ?>>5人</option>
                    <option value="6" <?php echo e(old('number') == 6 ? 'selected' : ''); ?>>6人</option>
                    <option value="7" <?php echo e(old('number') == 7 ? 'selected' : ''); ?>>7人</option>
                    <option value="8" <?php echo e(old('number') == 8 ? 'selected' : ''); ?>>8人</option>
                    <option value="9" <?php echo e(old('number') == 9 ? 'selected' : ''); ?>>9人</option>
                    <option value="10" <?php echo e(old('number') == 10 ? 'selected' : ''); ?>>10人以上</option>
                </select>
                <?php $__errorArgs = ['number'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <div class="reservation-form__error-message"><?php echo e($message); ?></div>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>

            <!-- 予約するボタン -->
            <button type="submit" name="action" value="reserve"
                class="reservation-form__button--submit">予約する</button>
        </form>
    </section>
    <!-- 予約詳細エリア -->
    <section class="reservation-summary__container">
        <div class="reservation-summary">
            <p class="reservation-summary__text">
                <strong>Shop</strong> <?php echo e($restaurant->name); ?>

            </p>
            <p class="reservation-summary__text">
                <strong>Date</strong> <?php echo e($latest_reservation ? $latest_reservation->reservation_date : 'N/A'); ?>

            </p>
            <p class="reservation-summary__text">
                <strong>Time</strong>
                <?php echo e($latest_reservation ? \Carbon\Carbon::parse($latest_reservation->reservation_time)->format('H:i') : 'N/A'); ?>

            </p>
            <p class="reservation-summary__text">
                <strong>Number</strong> <?php echo e($latest_reservation ? $latest_reservation->number_of_people : 'N/A'); ?>人
            </p>
        </div>
    </section>


</main>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.rese_layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/resources/views/restaurant_detail.blade.php ENDPATH**/ ?>