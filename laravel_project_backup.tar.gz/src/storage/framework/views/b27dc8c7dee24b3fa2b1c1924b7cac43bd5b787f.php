<?php $__env->startSection('css'); ?>
<link rel="stylesheet" href="<?php echo e(asset('css/thanks.css')); ?>">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

<main class="thanks__content">
    <div class="thanks__message-box">
        <p class="thanks__message">会員登録ありがとうございます</p>
        <form method="POST" action="<?php echo e(route('auto-login')); ?>">
            <?php echo csrf_field(); ?>
            <button type="submit" class="thanks__button">ログインする</button>

    </div>
</main>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.rese_layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/resources/views/thanks.blade.php ENDPATH**/ ?>