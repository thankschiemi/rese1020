<?php $__env->startSection('css'); ?>
<link rel="stylesheet" href="<?php echo e(asset('css/register.css')); ?>">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

<div class="register__container">
    <form class="register__form" action="<?php echo e(route('register.store')); ?>" method="POST">
        <?php echo csrf_field(); ?>
        <h2 class="register__form-title">Register</h2>

        <div class="register__form-group">
            <label for="username" class="register__label">
                <img src="<?php echo e(asset('images/person-image-20241022.png')); ?>" alt="メンバーアイコン" class="register__icon">
            </label>
            <input type="text" name="name" placeholder="Username" class="register__input" value="<?php echo e(old('name')); ?>">
            <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <div class="error"><?php echo e($message); ?></div>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>

        <div class="register__form-group">
            <label for="email" class="register__label">
                <img src="<?php echo e(asset('images/mail-icon.png')); ?>" alt="メールアイコン" class="register__icon">
            </label>
            <input type="email" name="email" placeholder="Email" class="register__input" value="<?php echo e(old('email')); ?>">
            <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <div class="error"><?php echo e($message); ?></div>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>

        <div class="register__form-group">
            <label for="password" class="register__label">
                <img src="<?php echo e(asset('images/key-image-20241022.png')); ?>" alt="パスワードアイコン" class="register__icon">
            </label>
            <input type="password" name="password" placeholder="Password" class="register__input">
            <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <div class="error"><?php echo e($message); ?></div>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>


        <button type="submit" class="register__button">登録</button>
    </form>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.rese_layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/resources/views/auth/register.blade.php ENDPATH**/ ?>