<?php $__env->startSection('css'); ?>
<link rel="stylesheet" href="<?php echo e(asset('css/account_settings.css')); ?>">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

<?php if(session('error')): ?>
<p class="alert alert-danger"><?php echo e(session('error')); ?></p>
<?php endif; ?>

<div class="menu">
    <nav class="menu__nav">
        <ul class="menu__list">
            <li class="menu__item">
                <a href="<?php echo e(url('/')); ?>" class="menu__link">Home</a> <!-- ホーム画面のリンク -->
            </li>
            <li class="menu__item">
                <a href="<?php echo e(url('/register')); ?>" class="menu__link">Registration</a> <!-- 新規登録画面へのリンク -->
            </li>
            <li class="menu__item">
                <a href="<?php echo e(url('/login')); ?>" class="menu__link">Login</a> <!-- ログイン画面へのリンク -->
            </li>
        </ul>
    </nav>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.rese_layouts_menu', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/resources/views/account_settings.blade.php ENDPATH**/ ?>