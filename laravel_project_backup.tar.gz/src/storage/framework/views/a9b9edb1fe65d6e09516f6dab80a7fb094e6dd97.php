<?php $__env->startSection('content'); ?>
<link rel="stylesheet" href="<?php echo e(asset('css/campaign.css')); ?>">

<main class="notification">
    <a href="<?php echo e(route('owner.dashboard')); ?>" class="notification__back-btn">ダッシュボードに戻る</a>
    <h1 class="notification__title">キャンペーン・お知らせメール送信</h1>
    <p class="notification__description">
        このフォームを使って、利用者様にキャンペーンやお知らせメールを送信できます。
    </p>

    <?php if(session('success')): ?>
    <p class="notification__success"><?php echo e(session('success')); ?></p>
    <?php endif; ?>
    <?php if(session('success-error')): ?>
    <p class="notification__success"><?php echo e(session('success-error')); ?></p>
    <?php endif; ?>

    <form method="POST" action="<?php echo e(route('owner.sendNotification')); ?>" class="notification__form" novalidate>
        <?php echo csrf_field(); ?>
        <div class="notification__form-group">
            <label for="subject" class="notification__label">件名:</label>
            <input type="text" id="subject" name="subject" class="notification__input" value="<?php echo e(old('subject')); ?>">
            <?php $__errorArgs = ['subject'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <div class="error-message"><?php echo e($message); ?></div>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>

        <div class="notification__form-group">
            <label for="message" class="notification__label">内容:</label>
            <textarea id="message" name="message" class="notification__textarea"><?php echo e(old('message', '')); ?></textarea>
            <?php $__errorArgs = ['message'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <div class="error-message"><?php echo e($message); ?></div>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>

        <button type="submit" class="notification__button">送信</button>
    </form>
</main>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.rese_layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/resources/views/owner/campaign.blade.php ENDPATH**/ ?>