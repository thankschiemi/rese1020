<?php $__env->startSection('css'); ?>
<link rel="stylesheet" href="<?php echo e(asset('css/restaurant_all.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('css/common_restaurant.css')); ?>">

<?php $__env->stopSection(); ?>

<?php $__env->startSection('header_filters'); ?>
<div class="header_filters">
    <form method="GET" action="<?php echo e(route('restaurants.index')); ?>" class="filter">
        <div class="filter-wrapper">
            <div class="filter-select">
                <select name="region_id" class="filter_area" onchange="this.form.submit()">
                    <option value="">All area</option>
                    <?php $__currentLoopData = $regions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $region): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($region->id); ?>" <?php echo e(request('region_id') == $region->id ? 'selected' : ''); ?>>
                        <?php echo e($region->name); ?>

                    </option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
                <div class="dropdown-icon">▼</div>
            </div>
        </div>
        <div class="filter-wrapper">
            <div class="filter-select">
                <select name="genre_id" class="filter_genre" onchange="this.form.submit()">
                    <option value="">All genre</option>
                    <?php $__currentLoopData = $genres; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $genre): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($genre->id); ?>" <?php echo e(request('genre_id') == $genre->id ? 'selected' : ''); ?>>
                        <?php echo e($genre->name); ?>

                    </option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
                <div class="dropdown-icon">▼</div>
            </div>
        </div>
        <div class="filter-wrapper">
            <div class="filter-select">
                <label for="keyword" class="sr-only">Search</label>
                <img src="<?php echo e(asset('images/glass-icon.png')); ?>" alt="Search Icon" class="search-icon">

                <input type="search" id="keyword" name="keyword" class="filter_search" placeholder="Search ..." value="<?php echo e(request('keyword')); ?>">
            </div>
        </div>
    </form>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="page_content" id="restaurants-favorite-section">
    <?php $__empty_1 = true; $__currentLoopData = $restaurants; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $restaurant): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
    <article class="restaurant" data-restaurant-id="<?php echo e($restaurant->id); ?>">
        <?php if($restaurant->image_url): ?>
        <img src="<?php echo e(asset('storage/' . $restaurant->image_url)); ?>" alt="店舗画像">
        <?php else: ?>
        <img src="<?php echo e(asset('images/default-image.png')); ?>" alt="デフォルト画像" class="default-image">
        <?php endif; ?>

        <div class="restaurant__details">
            <h2 class="restaurant__name"><?php echo e($restaurant->name); ?></h2>
            <p class="restaurant__tags">#<?php echo e($restaurant->region->name); ?> #<?php echo e($restaurant->genre->name); ?></p>
            <div class="restaurant_buttons">
                <a href="<?php echo e(route('restaurants.detail', $restaurant->id)); ?>" class="restaurant_button" aria-label="詳しくみるボタン">詳しくみる</a>
                <button class="restaurant_favorite-button <?php echo e($restaurant->is_favorite ? 'active' : ''); ?>"
                    aria-label="お気に入り追加"
                    data-authenticated="<?php echo e(Auth::check() ? 'true' : 'false'); ?>">
                    ❤
                </button>

            </div>
        </div>
    </article>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
    <p class="no_results">該当する飲食店は見つかりませんでした。</p>
    <?php endif; ?>
</div>

<script>
    document.addEventListener('DOMContentLoaded', function() {
        document.querySelectorAll('.restaurant_favorite-button').forEach(button => {
            button.addEventListener('click', function() {
                const isAuthenticated = this.getAttribute('data-authenticated') === 'true';

                if (!isAuthenticated) {
                    // ログインが必要な場合のポップアップ
                    alert('この機能を使用するにはログインが必要です。');
                    return;
                }

                // ログイン済みの場合、いいね処理を実行
                const restaurantId = this.closest('.restaurant').dataset.restaurantId;

                fetch(`/favorites/${restaurantId}`, {
                        method: 'POST',
                        headers: {
                            'Content-Type': 'application/json',
                            'X-CSRF-TOKEN': document.querySelector('meta[name="csrf-token"]').getAttribute('content')
                        }
                    })
                    .then(response => response.json())
                    .then(data => {
                        if (data.isFavorite) {
                            this.classList.add('active');
                        } else {
                            this.classList.remove('active');
                        }
                    })
                    .catch(error => {
                        console.error('Fetch Error:', error);
                    });
            });
        });
    });
</script>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.rese_layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/resources/views/restaurant_all.blade.php ENDPATH**/ ?>