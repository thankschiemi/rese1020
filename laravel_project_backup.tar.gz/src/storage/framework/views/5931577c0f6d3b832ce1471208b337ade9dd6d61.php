<?php $__env->startSection('css'); ?>
<link rel="stylesheet" href="<?php echo e(asset('css/common_restaurant.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('css/my_page.css')); ?>">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<main class="mypage">
    <div class="mypage__content">

        <!-- 左カラム：予約情報 -->
        <section class="mypage__reservations">
            <!-- フラッシュメッセージ表示 -->
            <?php if(session('success')): ?>
            <div class="alert alert-success">
                <?php echo e(session('success')); ?>

            </div>
            <?php endif; ?>

            <?php if(session('error')): ?>
            <div class="alert alert-danger">
                <?php echo e(session('error')); ?>

            </div>
            <?php endif; ?>

            <h2 class="mypage__status-title">予約状況</h2>
            <?php $__empty_1 = true; $__currentLoopData = $reservations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $reservation): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <div class="reservation-card" data-reservation-id="<?php echo e($reservation->id); ?>">
                <div class="reservation__card-header">
                    <div class="reservation__icon">
                        <img src="<?php echo e(asset('images/clock-image-20241022.png')); ?>" alt="時計アイコン">
                    </div>
                    <h3 class="reservation__card-title">予約<?php echo e($loop->iteration); ?></h3>
                </div>
                <form method="POST" action="<?php echo e(route('reserve.destroy', $reservation->id)); ?>" class="reservation__close-button">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('DELETE'); ?>
                    <button type="submit" class="close-icon"></button>
                </form>
                <ul class="reservation-card__details">
                    <li class="reservation-card__detail">
                        <span class="detail-label">Shop</span>
                        <span class="detail-value"><?php echo e($reservation->restaurant->name); ?></span>
                    </li>
                    <li class="reservation-card__detail">
                        <span class="detail-label">Date</span>
                        <span class="detail-value"><?php echo e($reservation->reservation_date); ?></span>
                    </li>
                    <li class="reservation-card__detail">
                        <span class="detail-label">Time</span>
                        <span class="detail-value"><?php echo e(date('H:i', strtotime($reservation->reservation_time))); ?></span>
                    </li>
                    <li class="reservation-card__detail">
                        <span class="detail-label">Number</span>
                        <span class="detail-value"><?php echo e($reservation->number_of_people); ?>人</span>
                    </li>
                </ul>
                <div class="reservation-card__buttons">
                    <a href="<?php echo e(route('reserve.edit', $reservation->id)); ?>" class="reservation-card__button reservation-card__button--change">予約の変更</a>
                    <button type="button" class="reservation-card__button reservation-card__button--refresh" onclick="location.reload();">更新</button>
                    <a href="<?php echo e(route('reviews.create', $reservation->id)); ?>" class="reservation-card__button reservation-card__button--rate">評価</a>
                </div>
                <div class="qr-code-wrapper">
                    <div class="qr-code">
                        <?php echo QrCode::encoding('UTF-8')->size(100)->generate($reservation->qrData); ?>

                    </div>
                    <p class="qr-instruction">このQRコードを店舗スタッフに提示してください</p>
                </div>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <p class="no_results">予約情報がありません。</p>
            <?php endif; ?>
        </section>

        <!-- 右カラム：お気に入り店舗 -->
        <section id="mypage-favorite-section" class="mypage__favorites">
            <p class="mypage__user-name"><?php echo e($user->name); ?>さん</p>
            <h2 class="mypage__section-title">お気に入り店舗</h2>
            <div class="favorites__list">
                <?php $__empty_1 = true; $__currentLoopData = $favorites; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $favorite): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <article class="restaurant" data-restaurant-id="<?php echo e($favorite->restaurant->id); ?>">
                    <div class="restaurant__image">
                        <?php if($favorite->restaurant->image_url): ?>
                        <img src="<?php echo e(asset('storage/' . $favorite->restaurant->image_url)); ?>" alt="店舗画像" class="restaurant__image">
                        <?php else: ?>
                        <img src="<?php echo e(asset('images/default-image.png')); ?>" alt="デフォルト画像" class="default-image">
                        <?php endif; ?>
                    </div>
                    <div class="restaurant__details">
                        <h2 class="restaurant__name"><?php echo e($favorite->restaurant->name); ?></h2>
                        <p class="restaurant__tags">#<?php echo e($favorite->restaurant->region->name); ?> #<?php echo e($favorite->restaurant->genre->name); ?></p>
                        <div class="restaurant_buttons">
                            <a href="<?php echo e(route('restaurants.detail', $favorite->restaurant->id)); ?>" class="restaurant_button">詳しくみる</a>
                            <button class="restaurant_favorite-button <?php echo e($favorite->restaurant->is_favorite ? 'active' : ''); ?>">❤</button>
                        </div>
                    </div>
                </article>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <p class="no_results">お気に入り店舗がありません。</p>
                <?php endif; ?>
            </div>
        </section>

    </div>
</main>

<script>
    document.querySelectorAll('.restaurant_favorite-button').forEach(button => {
        button.addEventListener('click', function() {
            const restaurantId = this.closest('.restaurant').dataset.restaurantId;

            fetch(`/favorites/${restaurantId}`, {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json',
                        'X-CSRF-TOKEN': document.querySelector('meta[name="csrf-token"]').getAttribute('content')
                    }
                })
                .then(response => {
                    if (!response.ok) {
                        throw new Error('Network response was not ok');
                    }
                    return response.json();
                })
                .then(data => {
                    if (data.isFavorite) {
                        this.classList.add('active');
                    } else {
                        this.classList.remove('active');
                        this.closest('.restaurant').remove();
                    }
                })
                .catch(error => {
                    console.error('Error:', error);
                });
        });
    });
</script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.rese_layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/resources/views/my_page.blade.php ENDPATH**/ ?>