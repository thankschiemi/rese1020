<?php $__env->startSection('css'); ?>
<link rel="stylesheet" href="<?php echo e(asset('css/main_menu.css')); ?>">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

<div class="menu">
    <nav class="menu__nav">
        <ul class="menu__list">
            <li class="menu__item">
                <a href="<?php echo e(url('/')); ?>" class="menu__link">Home</a> <!-- ホーム画面のリンク -->
            </li>
            <li class="menu__item">
                <form method="POST" action="<?php echo e(route('logout')); ?>" class="menu__form">
                    <?php echo csrf_field(); ?>
                    <button type="submit" class="menu__link">Logout</button>
                </form>
            </li>
            <li class="menu__item">
                <a href="<?php echo e(url('/mypage')); ?>" class="menu__link">Mypage</a> <!-- アカウント設定へのリンク -->
            </li>
            
            <?php if(Auth::user()->role === 'admin'): ?>
            <li class="menu__item">
                <a href="<?php echo e(route('admin.dashboard')); ?>" class="menu__link">Admin Dashboard</a>
            </li>
            <?php endif; ?>

            
            <?php if(Auth::user()->role === 'owner'): ?>
            <li class="menu__item">
                <a href="<?php echo e(route('owner.dashboard')); ?>" class="menu__link">Owner Dashboard</a>
            </li>
            <?php endif; ?>

        </ul>
    </nav>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.rese_layouts_menu', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/resources/views/main_menu.blade.php ENDPATH**/ ?>