<?php $__env->startSection('css'); ?>
<link rel="stylesheet" href="<?php echo e(asset('css/reservation_done.css')); ?>">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

<main class="done__content">
    <div class="done__message-box">
        <p class="done__message">ご予約ありがとうございます</p>

        <!-- 決済画面へ進むボタン -->
        <a href="<?php echo e(route('payment.page')); ?>" class="payment-button">決済画面へ進む</a>

        <!-- 戻るボタン -->
        <a href="<?php echo e(url()->previous()); ?>" class="back-button">戻る</a>
    </div>
</main>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.rese_layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/resources/views/reservation_done.blade.php ENDPATH**/ ?>