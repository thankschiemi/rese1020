<?php $__env->startSection('content'); ?>
<link rel="stylesheet" href="<?php echo e(asset('css/manage_reservations.css')); ?>">
<main class="store-list">
    <a href="<?php echo e(route('owner.dashboard')); ?>" class="btn">ダッシュボードに戻る</a>
    <h1 class="store-list__title">予約情報の確認画面</h1>
    <p><?php echo e(Auth::check() ? Auth::user()->name : 'ゲスト'); ?>さんが管理するすべての店舗の予約情報です。</p>


    <?php if(!empty($reservations)): ?>
    <table class="store-list__table">
        <thead>
            <tr>
                <th>店舗名</th>
                <th>予約のお客様</th>
                <th>日時</th>
                <th>人数</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $reservations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $reservation): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e(optional($reservation->restaurant)->name ?? '店舗なし'); ?></td>
                <td><?php echo e(optional($reservation->member)->name ?? '利用者なし'); ?></td>
                <td><?php echo e($reservation->reservation_date ?? '未設定'); ?> <?php echo e(\Carbon\Carbon::parse($reservation->reservation_time)->format('H:i')); ?></td>
                <td><?php echo e($reservation->number_of_people ?? '未設定'); ?></td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
    <?php else: ?>
    <p>現在予約情報はありません。</p>
    <?php endif; ?>
</main>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.rese_layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/resources/views/owner/manage_reservations.blade.php ENDPATH**/ ?>