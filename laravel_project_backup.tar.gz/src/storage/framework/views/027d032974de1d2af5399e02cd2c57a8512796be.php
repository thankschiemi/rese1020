<!DOCTYPE html>
<html>

<head>
    <title>お知らせメール</title>
</head>

<body>
    <h1><?php echo e($subject); ?></h1> <!-- 件名 -->
    <p><?php echo e($emailMessage); ?></p> <!-- メール本文 -->
    <p>Reseをご利用いただきありがとうございます。</p>
</body>

</html><?php /**PATH /var/www/resources/views/emails/notification.blade.php ENDPATH**/ ?>