<?php $__env->startSection('content'); ?>
<link rel="stylesheet" href="<?php echo e(asset('css/store_list.css')); ?>">
<main class="store-list">
    <a href="/owner/dashboard" class="btn btn-primary">ダッシュボードに戻る</a>
    <h1 class="store-list__title"><?php echo e($user->name); ?>さんの店舗一覧</h1>
    <?php if(session('success')): ?>
    <p class="success-message"><?php echo e(session('success')); ?></p>
    <?php endif; ?>



    <?php if($stores && $stores->count() > 0): ?>
    <table class="store-list__table">
        <thead>
            <tr>
                <th>店舗名</th>
                <th>地域</th>
                <th>ジャンル</th>
                <th>操作</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $stores; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $store): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($store->name); ?></td>
                <td><?php echo e($store->region->name ?? '未設定'); ?></td>
                <td><?php echo e($store->genre->name ?? '未設定'); ?></td>
                <td><a href="<?php echo e(route('owner.store_edit', $store->id)); ?>">編集</a></td>

            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
    <?php else: ?>
    <p>店舗情報が見つかりません。新しく店舗を登録してください。</p>
    <?php endif; ?>
</main>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.rese_layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/resources/views/owner/store_list.blade.php ENDPATH**/ ?>